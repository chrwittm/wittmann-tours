---
title: 'Arequipa, die weiße Stadt'
description: ""
published: 2018-10-29
redirect_from: 
            - https://wittmann-tours.de/arequipa-die-weisse-stadt/
categories: "Arequipa, Ekeko, Juanita, Käseeis, kulinarisch, Peru, Peru, Sillar"
hero: ../../../defaultHero.jpg
---
# Arequipa, die weiße Stadt

Endlich ein Ort, an dem wir nicht dauernd von der Seite angesprochen wurden, welch eine Erholung nach [Cuzco](http://wittmann-tours.de/cuzco-die-ehemalige-inka-hauptstadt/) und [Machu Picchu](http://wittmann-tours.de/machu-picchu-entzaubert-aber-sehenswert/)! Mit unserem Besuch der zweitgrößten Stadt Perus entkamen wir dem Tourismusrummel, obwohl wir mitten im historischen Zentrum von Arequipa, der weißen Stadt, wohnten. Zwar waren einige Ausländer unterwegs, aber die Stimmung war durchwegs sehr entspannt und freundlich. So konnten wir denn die Geburtsstadt von [Mario Vargas Llosa](https://de.wikipedia.org/wiki/Mario_Vargas_Llosa) in Ruhe besichtigen.

![Die Kathedrale von Arequipa, in weißen Sollar erbaut. Ihr Innenleben hat sich mit sporadischen Öffnungszeiten leider vor uns versteckt.](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180513-163840-2560-HDR-1024x683.jpg)

<!--more-->

## Weiß statt rot

Arequipa sieht schon auf den ersten Blick deutlich anders aus als viele andere peruanische Städte, deren Häuser vielfach aus unverputztem roten Backstein erbaut sind. Hier war die vorherrschende Farbe weiß. Der vulkanische Stein, der durchgehend in der Altstadt als Baumaterial Verwendung fand, heißt [Sillar](https://en.wikipedia.org/wiki/Sillar). Diese relativ leichte, weiche Art von Gestein ließ sich gut bearbeiten. Kirchen und andere repräsentative Gebäude, die heute Banken oder Museen beherbergen, weisen prachtvolle Steinmetzarbeiten auf.

![Arequipa in bestem weißen Sillar: Casa de Moral, heute beherbergt es ein Museum.](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180513-082401-2461-1024x683.jpg)

Angeblich herrscht in Arequipa fast das ganze Jahr über ein sehr angenehmes Klima. Für die Zeit, die wir dort verbrachten, können wir das bestätigen. Tagsüber war es in der Sonne warm, aber nicht extrem heiß, vielleicht 20 bis 25 Grad Celsius. Im Schatten zogen wir jedoch auch am Tag ab und zu einen Pullover über. Nachts kühlte es auf ca. 10 Grad ab, was allerdings im Umkehrschluss hieß, dass es beim Frühstück, das draußen stattfand, kaum wärmer war. (Es erinnerte uns ein wenig an das Kindergeburtstagspiel „Schokoladenessen“, wenn wir eingemummelt in Mütze und Schal vor unserem Teller saßen und uns nur schwer dazu überwinden konnten, zum Essen die Handschuhe auszuziehen.) Niederschlag gibt es wenig, mittlerweile wohl zu wenig, und das Wasser ist knapp. Auf gerade einmal 2350 Metern über dem Meeresspiegel spürten wir auch die Höhe deutlich weniger.

![Kreuzgang mit feinen Steinmetzarbeiten neben der Iglesia de la Compañia de Jesus](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180513-101507-0495-1024x683.jpg)

Weiterhin fällt in Arequipa die Abwesenheit von Hochhäusern wohltuend auf, obwohl es eine echte Großstadt ist. Angeblich sind immer wieder auftretende Erdbeben der Grund hierfür, zuletzt [2001](http://www.spiegel.de/panorama/peru-mindestens-47-tote-bei-erdbeben-a-141556.html). Von vielen Punkten in der Stadt kann man die herrliche Gebirgskulisse bewundern. Majestätisch erheben sich die schneebedeckten Berggipfel von [Chachani](https://de.wikipedia.org/wiki/Chachani) (6075m), [Misti](https://de.wikipedia.org/wiki/Misti) (5822m) und [Picchu Picchu](https://de.wikipedia.org/wiki/Picchu_Picchu) (5664m) rund um Arequipa herum.

![Brück über den Rio Chili in Arequipa, im Hintergrund der Chachani](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180513-092035-0483-1024x683.jpg)

## Juanita, die Jungfrau aus dem Eis

Inkageschichte kann man auch in Arequipa erleben, allerdings gibt es dort keine Ruinen zu sehen. Der Spitzname der großen Sehenswürdigkeit ist [Juanita](<https://de.wikipedia.org/wiki/Juanita_(Mumie)>). In Gipfelnähe des Berges [Ampato](https://de.wikipedia.org/wiki/Ampato) auf über 5000 Metern Höhe wurde 1995 der noch größtenteils gefrorene Leichnam eines etwa 12-jährigen Inka-Mädchens gefunden. Der Vergleich mit [Ötzi](https://de.wikipedia.org/wiki/%C3%96tzi) läge nahe, die Peruaner bestehen jedoch darauf, dass Juanita keine Mumie ist, da noch Feuchtigkeit in Form von Eis in ihrem Gewebe vorhanden ist. Gefunden wurde die kühle Schönheit von einer Expedition unter Leitung des US-amerikanischen Archäologen Johan Reinhard, der sie geborgen und alles für ihre Erhaltung getan hat. Nach seinem Vornamen hat das Inka-Mädchen seinen Spitznamen erhalten. Im [Museo Santuarios Andinos](http://www.ucsm.edu.pe/museo-santuarios-andinos/) können interessierte Besucher Juanita - weiterhin gefroren - in ihrem eisigen Glassarg ansehen.

Fotografieren war im Museum leider nicht erlaubt und es gibt online keine Bilder unter Creative Commons Lizenz. Ein Bild von Juanita findet Ihr [hier](https://peru.info/es-lat/TURISMO/Noticias/3/17/la-momia-juanita---la-dama-de-ampato-).

Was aber hatte Juanita dazu bewegt, auf den hohen Gipfel zu steigen? Die Inka verehrten damals die höchsten Berge als Gottheiten. Nur selten wagten sie sich dorthin, um ihnen zu huldigen und sie zu besänftigen. Juanita - vermutlich eine Schönheit aus adeligem Hause - war wohl auserwählt worden, für die Berggötter den Opfertod zu sterben. Sie muss also die Strapazen des Aufstieges auf sich genommen haben und wurde dann von den begleitenden Priestern rituell getötet. Später umschloss ewiges Eis den Leichnam, bis dieses durch einen Ascheregen des nahegelegenen Vulkans [Sabancaya](https://de.wikipedia.org/wiki/Sabancaya) auftaute. Durch glückliche Umstände wurde sie wenige Tage später gefunden und zu Forschungszwecken wieder eingefroren.

_Ein weiteres Bild von Juanita findet Ihr [hier](https://andina.pe/agencia/noticia-celulas-madre-dama-ampato-son-conservadas-su-cordon-umbilical-500431.aspx)._

Zur Einführung wurde im [Museo Santuarios Andinos](http://www.ucsm.edu.pe/museo-santuarios-andinos/) ein National Geographic-Video (Kurzversion [hier](https://www.youtube.com/watch?v=Vvu3jI41rsk)) zu den Hintergründen der Entdeckung und Bergung des jungen Opfers gezeigt. Während einer Führung sahen wir Artefakte mehrerer Opferstätten, erfuhren einiges zum Forschungsstand über solche Inka-Rituale und durften schließlich Juanita selbst bestaunen. Der Hauptsehenswürdigkeit angemessen war es im ganzen Museum bitterkalt, nicht nur in ihrem gläsernen Tiefkühlschrank, in dem sie auf -19 Grad Celsius gekühlt ist. So waren wir nach Ende der Besichtigung froh, uns draußen wieder aufwärmen zu können.

## Die Markthalle von Arequipa

In Arequipa gibt es noch einige Tambos. Dabei handelt es sich um einfache Herbergen der Inka bzw. der indigenen Bevölkerung. Auf einem Rundgang besuchten wir erst mehrere dieser urigen Tambos und dann die Markthalle. Dort gab es alles, was das Herz begehrte: Verschiedenste Früchte, alle Arten von Kartoffeln, Fleisch, Fisch, alles frisch, aber bestimmt nicht steril ;). Außerdem wurden auch Heilkräuter, Liebesdüfte und kleine Ekeko-Figuren angeboten.

![Ein Ekeko, nicht vom Markt aus Areqipna, sondern im Museo Nacional de Etnografía y Folklore in Sucre, Bolivien (4 Wochen später)](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180606-143938-2418-1024x683.jpg)

[Ekeko](https://en.wikipedia.org/wiki/Ekeko) ist der präkolumbianische Gott des Wohlstandes und Überflusses (aus der [Tiwanaku](https://de.wikipedia.org/wiki/Tiahuanaco)-Kultur), der auch heute noch verehrt wird. Während des Alasitas-Festes können Miniatur-Ausgaben aller erträumten materiellen Besitztümer (von einem Körbchen mit Cocablättern über ein Bündel von winzigen Geldscheinen bis hin zum aufgemotzten Matchbox-Pick-up-Truck) von einem indigenen Hexenmeister gesegnet und der kleinen Statue aufgebürdet werden, in der Hoffnung auf baldige Erfüllung aller dieser Wünsche. Auch Lama-Föten sind erhältlich. In Peru ist es traditionell Sitte, vor Errichtung eines Neubaus einen solchen unter dem Eckstein des geplanten Hauses zu vergraben als Opfer für Pachamama (die Erdgöttin).

![Die Markthalle von Arequipa](http://wittmann-tours.de/wp-content/uploads/2018/10/CW-20180513-105843-0503-HDR-1024x683.jpg)

## Arequipa historisch und kulinarisch

Besonders beeindruckt hat uns der Besuch des historischen [Klosters St. Catalina](https://de.wikipedia.org/wiki/Kloster_Santa_Catalina), zu Gründungszeiten eine Art Institution für Töchter wohlhabender Eltern. Die Familien zahlten für die Aufnahme der Mädchen eine hohe Summe. Die Ordensschwestern lebten dort früher in zahlreichen kleinen Häusern mit ihren Dienerinnen. Dadurch war eine verwinkelte Stadt in der Stadt entstanden. Mit ihren niedrigen Gebäuden, die in leuchtenden Farben gestrichen waren (rostrot oder knallig blau), erinnerte die Anlage an ein mittelalterliches spanisches Dorf. Das tägliche Leben der Nonnen wurde zwar durch verschiedene Gebetszeiten geregelt, bot aber auch viele Annehmlichkeiten. Vor allem wenn man die Alternative berücksichtigt, dass die Mädchen sonst mit 12 oder 13 Jahren verheiratet worden wären, einen zahlreichen Nachwuchs hätten gebären müssen und mit Kindern und Haushalt alle Hände voll zu tun gehabt hätten, war das Leben als Ordensschwester bestimmt vergleichsweise bequem.

![Atmosphärische Stimmung im Kloster St. Catalina](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180513-121310-2507-683x1024.jpg)

Auf unserem Rundgang lernten wir auch eine schmackhafte regionale Spezialität kennen: Käse-Eis. Hört sich eigenartig an, ist aber erstaunlich gut. Wer jetzt einen herzhaften Käsegeschmack erwartet, wird enttäuscht werden. Das Eis war sehr cremig und schmeckte in etwa wie die gefrorene Füllung eines Käsekuchens.

![Leckeres Käse-Eis!](http://wittmann-tours.de/wp-content/uploads/2018/09/CW-20180513-100706-0488-1024x683.jpg)
