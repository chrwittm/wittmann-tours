---
title: 'Antananarivo und Akamasoa'
description: ""
published: 2019-06-16
redirect_from: 
            - https://wittmann-tours.de/antananarivo-und-akamasoa/
categories: "Akamasoa, Antananarivo, Bildung, Gottesdienst, Hilfe, Madagaskar, Manantenasoa, Pater Pedro, Rova"
hero: ../../../defaultHero.jpg
---
# Antananarivo und Akamasoa

Nach knapp zwei Wochen im Westen Madagaskars kehrten wir nach Antananarivo zurück. Neben ein paar Besorgungen unternahmen wir eine kurze Stadtbesichtigung. Den wohl tiefsten Eindruck hinterließ ein Besuch bei Pater Pedro und seiner Vereinigung "[Akamasoa](https://de.wikipedia.org/wiki/Akamasoa_Association)" mit seiner erstaunlichen positiven Parallelwelt.

![Pater Pedro, Missionar, Priester und Gründer von Akamasoa](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-102536-9289-1024x683.jpg)

<!--more-->

## Die Stadt der Könige

Historisch betrachtet war Antananarivo zunächst nur Hauptstadt und Königssitz der Merina, einem der vielen Völker Madagaskars. Ab Ende des 18. Jahrhunderts begann sich die Macht in Madagaskar zu zentralisieren. Die Merina herrschten über weite Teile der Insel bis die Franzosen 1896 auf Madagaskar die Herrschaft übernahmen und die letzte Königin Ranavalona III. zum Abdanken zwangen.

![Der Rova thront auf dem höchsten Punkt von Antananarivo](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-134446-7859-1024x683.jpg)

Zentrum der Macht zur Zeit der Herrschaft der Merina-Könige war der sogenannte [Rova](https://de.wikipedia.org/wiki/Rova_von_Antananarivo), der Königspalast. Seit dem 17. Jahrhundert thront er (bzw. seine Vorgänger) auf der höchsten Erhebung der Stadt. Damit ist er von vielen Orten Antananarivos aus sichtbar und man hat von oben einen eindrucksvollen Rundumblick über die ganze Stadt.

## Brand, Zerstörung und Hoffnung

1995 verwüstete [ein verheerender Brand](https://en.wikipedia.org/wiki/Rova_of_Antananarivo#Destruction) den Rova nahezu vollständig. Die Gräber und sterblichen Überreste der früheren Könige (der Ahnen) und viele historische Artefakte wurden zerstört. Die Ursache des Feuers ist bis heute ungeklärt, offiziell wurde es als Unfall abgetan. Es kursieren jedoch immer noch zahllose Gerüchte und Theorien über verschiedentlich politisch motivierte Brandstiftung. Bis heute sind nur die Außenmauern des Palastes rekonstruiert. Damit könnte man den Rova vielleicht als Symbol der ausgehöhlten politischen Macht in Madagaskar ansehen.

![Ein Blick auf das eigene Reich: Antananarivo vom Rova aus betrachtet](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-132949-9330-1024x576.jpg)

Neben den zahlreichen herzlichen Begegnungen und den Naturwundern hatten wir in den zurückliegenden Tagen auch viel Armut miterlebt und eine Ahnung davon bekommen, was die Ursachen dafür sein könnten: Korruption, mangelhafte Infrastruktur, Desinteresse der Herrschenden. Es gibt jedoch in Antananarivo Orte, an denen vieles anders ist. Dahinter steckt die Vereinigung "[Akamasoa](https://de.wikipedia.org/wiki/Akamasoa_Association)". Der auf Madagaskar sehr bekannte und geachtete Priester Pater Pedro begründete dieses Projekt. Da gerade Sonntag war, nutzten wir die Gelegenheit, in Manantenasoa den großen Gottesdienst mit Pater Pedro zu besuchen.

## Gottesdienst in einer Sporthalle

Die Anbetungsstätte und der Gottesdienst hatten wenig mit unserer Vorstellung einer sonntäglichen Messe zu tun. Als Kirche diente eine offene Sporthalle, in der sich 5000 bis 6000 Menschen drängten. Als wir ankamen, hatte der Gottesdienst schon begonnen. Statt stiller Andacht herrschte eine fröhliche und ungezwungene Stimmung. Musik und Gesang füllten die Arena aus und wir waren bei weitem nicht die einzigen, die sich durch die Gänge bewegten.

![Gottesdienst in der Sporthalle von Akamasoa](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-100044-7849-1024x683.jpg)

Bei all der Betriebsamkeit in der Halle war es nicht immer leicht zu verstehen, was sich gerade abspielte. Zunächst fand eine Massentaufe statt, bei der Pater Pedro mit geweihtem Öl ein Kreuz auf die Stirn seiner Täuflinge zeichnete. Dabei standen die Gläubigen ebenso wie bei der späteren Kommunion in einer langen Schlange an, bis sie an der Reihe waren. Untermalt wurde das Geschehen von Musik und Gesang. Immer wieder erhoben sich Gruppen bunt kostümierter Kinder, die synchrone Tanzbewegungen vollführten. Einzig bei der Predigt schallte nur Pater Pedros Stimme durch die Halle, natürlich auf Malagasy. Gerne hätten wir verstanden, was er sagte. Insgesamt dauerte der Gottesdienst beachtliche vier Stunden. Das folgende Video zeigt ein paar Impressionen:

https://www.youtube.com/watch?v=YLZy06rdprU

## Die Geschichte von Pater Pedro

Der Seele des Gottesdienstes war [Pater Pedro](https://de.m.wikipedia.org/wiki/Pedro_Opeka), ein katholischer Priester des Ordens der [Lazaristen](https://de.wikipedia.org/wiki/Lazaristen) (bzw. Vinzentiner) slowenischer Abstammung, der seine Kindheit in Buenos Aires verbracht hatte. Seit mittlerweile 30 Jahren wirkt Pater Pedro in Madagaskar und hat Erstaunliches aufgebaut. Bei der Arbeit mit [Müllkindern](https://de.m.wikipedia.org/wiki/Müllsucher) erkannte er, dass Worte angesichts dieses Elend nicht ausreichen. Daraufhin gründete er das Projekt "Akamasoa" was so viel bedeutet wie "Gute Freunde".

![Auf den Straßen von Akamasoa](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-115431-7854-1024x683.jpg)

Heute gehören zur Vereinigung 17 Dörfer im Stadtgebiet von Antananarivo, in denen mehr als 20.000 Menschen leben. Dort werden Menschen aufgenommen, die unverschuldet in Not geraten sind. Es gibt 72 Schulen, 3 Mittelschulen und ein Gymnasium mit insgesamt 280 Lehrern und Schulspeisung für die Kinder. Außerdem arbeiten 40 Ärzte für "Akamasoa" und das angeblich modernste Krankenhaus Madagaskars gehört ebenfalls zum Projekt. Was sich gut anhört, sieht auch gut aus, denn die "Akamasoa"-Siedlung Manantenasoa unterscheidet sich wohltuend vom Trubel in Antananarivo.

## "Akamasoa", Dörfer in der Großstadt

Die Straßen waren sauber und in gutem Zustand, es gab keinen motorisierten Verkehr. Die Häuser wirkten gepflegt und waren in fröhlichen Pastellfarben gestrichen. Ein [potemkinsches Dorf](https://de.wikipedia.org/wiki/Potemkinsches_Dorf) oder Realität überall in den "Akamasoa"-Siedlungen? Es glänzte nicht alles durch Perfektion, viele Wasserpumpen funktionierten zum Beispiel nicht und Becken zum Wäschewaschen waren auseinandergebrochen. Auf keinen Fall aber ist Pater Pedro nach unserem Eindruck ein Blender, sondern er hat mit "Akamasoa" quasi einen Staat im Staat mit eigener Infrastruktur und einem Verantwortungsgefühl gegenüber den Menschen geschaffen. Damit hat er genau das umgesetzt, was man sich von einer Regierung erwarten würde.

![Feierlich gekleidete Täuflinge](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-101149-9271-1024x683.jpg)

Wie kann das funktionieren? Warum sieht es nicht überall in Antananarivo so aus wie in den Dörfern von "Akamasoa"? Hinter dem Projekt steht eine ordnende Kraft, die Regeln erlässt und diese durchsetzt. Das Betteln zum Beispiel war in Manantenasoa verboten. Wir waren nicht die einzigen Besucher und wir haben nicht gesehen, dass jemand um Geld gebeten wurde. Was wären sonst die Konsequenzen gewesen? Sicher wirkt der religiöse Hintergrund dieser Gemeinschaft als Bindeglied und Legitimation, außerdem erhält die Vereinigung internationale Spenden. Und trotzdem steht hinter der Utopie von "Akamasoa" auch eine gewisse ökonomische Logik.

## "Akamasoa" für alle?

Pater Pedro hat viel erreicht, wurde dafür oft ausgezeichnet und war sogar für den Friedensnobelpreis nominiert. Tief verwurzelt in seiner Gemeinde schien es ihm sichtlich Spaß zu machen, die Messe in diesem kleinen Großstadtdorf zu feiern, das vielen bedürftigen Menschen eine Heimat bietet und zeigt, dass Armut auf Madagaskar kein unveränderliches Schicksal sein muss. Wenn auch die Kapazitäten des Projekts endlich sind, so erschließen sich die zugrundeliegenden Ideen jedem und sie werden durch die Vereinigung konsequent umgesetzt.

![Pater Pedro spendet den Segen](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-103917-9295-1024x683.jpg)

"Akamasoa" bietet den Einwohnern der Siedlungen Arbeit und die Möglichkeit, sich in der Gemeinschaft einzubringen. Das bedeutet auch körperlichen Einsatz, z.B. im Steinbruch oder beim Bau der Häuser. Disziplin und Motivation werden erwartet. Dabei kommt die Arbeitskraft der Einzelnen dem Wohl der Gemeinschaft zugute. Außerdem sind Erziehung und Ausbildung ein klarer Fokus von "Akamasoa", um vor allem den Kindern und Jugendlichen die Basis für eine sichere Zukunft mitzugeben und damit den Teufelskreis aus Armut und Perspektivlosigkeit zu durchbrechen.

![Tanzende Kinder in den madegassischen Landesfarben (und gelb)](http://wittmann-tours.de/wp-content/uploads/2019/06/CW-20180812-110955-9301-1024x683.jpg)

Diese Grundideen erinnern doch fast ein wenig an die kommunistische Ideologie. Auf jeden Fall scheint das tägliche Leben für die Menschen in Manantenasoa besser zu funktionieren als in der Großstadt Antananarivo. Warum nicht überall in Madagaskar ein bisschen mehr "Akamasoa" wagen?
