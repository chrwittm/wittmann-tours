---
title: 'Ecuador kulinarisch: Spezialitäten der Hochland-Küche'
description: ""
published: 2018-09-09
redirect_from: 
            - https://wittmann-tours.de/ecuador-kulinarisch-spezialitaeten-der-hochland-kueche/
categories: "Canelazo, cuy, deftig, Ecuador, Ecuador, Hochland, Kartoffeln, kulinarisch, Locro, Mais, Meerschweinchen, Popcorn, Suppe"
hero: ../../../defaultHero.jpg
---
# Ecuador kulinarisch: Spezialitäten der Hochland-Küche

Die ecuadorianische Hochland-Küche ist nicht für exotische Gewürze oder raffinierte Kreationen bekannt. Trotzdem hat Ecuador viele schmackhafte und für uns ungewöhnliche Gerichte auf der Speisekarte. Werfen wir einen Blick auf einige typische Speisen und ein vielleicht etwas kontroverses Gericht.

![Die ecuadorianische Küche ist auf der deftigen Seite. Dies ist ein Churrasco Ecuatoriano.](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1486-1024x768.jpg)

<!--more-->

## Popcorn als Gruß aus der Küche

Auf dem amerikanischen Kontinent ist Mais traditionell eine der stützenden Säulen der Ernährung. In Ecuador merkte man das gleich zu Anfang der Menüfolge. Bekommt man im Lokal in Europa oder Nordamerika Brot und Butter angeboten, wird in Ecuador stattdessen Popcorn (cangil) serviert, geschmacklich eher neutral oder leicht gesalzen. Zuerst dachten wir, dass es eine interessante Idee sei, Popcorn zu servieren. Je länger wir uns jedoch in Ecuador aufhielten, desto mehr realisierten wir, dass dies normaler Standard war.

![Statt Brot und Butter, in Ecuador wird Popcorn serviert.](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1481-1024x768.jpg)

Eine andere Maisvariante, die uns sehr gut geschmeckt hat und die sich auch schön knabbern lässt, ist getoasteter Mais. Die Maiskörner sind geröstet, aber nicht gepoppt und dadurch schön knackig. Gerne knusperten wir den getoasteten Mais auch als Snack für zwischendurch. Diese Variante wurde auch manchmal als Beilage serviert.

![Mais tostado y cangil - Getoasteter Mais und Popcorn](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1404-1024x768.jpg)

## Weitere Maisgerichte: Tamales und Humitas

Weitere sehr traditionelle Maisgerichte sind [Tamales](<https://de.wikipedia.org/wiki/Tamale_(Gericht)>) und Humitas. Bei Tamales handelt es sich um einen Teig aus Maismehl, der am häufigsten mit Schweinefleisch oder Käse gefüllt und in Bananen- oder Maisblätter gewickelt wird. Die entstandenen Päckchen werden gedämpft. Die Zubereitung und der Verzehr gehen bereits auf Maya und Azteken zurück. Heute bekommt man sie in verschiedenen Variationen von Mexiko bis nach Peru. Uns erschienen sie ein wenig wie eine warme sättigende Variante eines belegten Brotes, das je nach Füllung eher mild bis würzig ausfallen kann.

![Eine Humita ecuadorianischer Art](http://wittmann-tours.de/wp-content/uploads/2018/08/APC_1402-1024x768.jpg)

Humitas könnte man als Unterart der Tamales bezeichnen. In Ecuador enthält der Teig frische zerkleinerte Maiskörner und Käse, aber keine gesonderte Füllung. Das Gericht schmeckt saftig und einen Hauch süßlich. Wahrscheinlich hilft der Verzehr auch gegen die Höhenkrankheit, mit Sicherheit gaben uns die Humitas Kraft für das ausgedehnte Besichtigungsprogramm in Quito.

## Etwas gegen die Kälte

Popcorn gibt es aber nicht nur als Appetitanreger, sondern auch als Beilage, in der Regel zu Suppen. Diese sind aufgrund des frischen Klimas bestens geeignet, um ausgekühlte Glieder wieder aufzuwärmen. Typisch ist zum Beispiel Kartoffelsuppe ([Locro](https://de.wikipedia.org/wiki/Locro) de Papa) mit Käse und Avocado. Das Popcorn kann man entweder dazu essen oder wie Croutons in die Suppe geben. Beides schmeckt erstaunlich gut. So kann man die ecuadorianische Küche auch schnell mal zu Hause imitieren ;).

![Locro de Papa, eine kräftige Kartoffelsuppe mit Käse, Tomate und Avocado als Einlage](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1426-1024x768.jpg)

Auch [Canelazo](https://de.wikipedia.org/wiki/Canelazo) eignet sich bestens zum Aufwärmen. Hierbei handelt es sich um ein heißes alkoholisches Getränk, das einfach herzustellen ist, wenn man die richtigen Zutaten bekommt: [Naranjillasaft](https://de.wikipedia.org/wiki/Lulo) (eine Zitrusfrucht, die wie eine Mini-Orange aussieht und auch so ähnlich schmeckt) und [Aguardiente](https://de.wikipedia.org/wiki/Aguardiente) (das ecudorianische Feuerwasser). Einige Varianten, die wir probierten, schmeckten gesüßt. Am besten ist Canelazo unserer Meinung nach aber ohne oder mit geringer Zugabe von Zucker. Die Zutaten mischen, aufwärmen und mit etwas Zimt (eigentlich namensgebend: Zimt heiß auf Spanisch canela) servieren. Das Ergebnis schmeckt wie eine sehr fruchtige Variante von Glühwein. Wenn man nicht an Naranjilla kommt, kann man auch andere Früchte verwenden, zum Beispiel Ananas. Je nach Frucht könnte das Ergebnis aber recht süß ausfallen.

![Glühwein auf eduadorianisch: Canelazo](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1427-1024x768.jpg)

## Deftige Hauptgerichte

Die andere wichtige Grundzutat der ecuadorianischen Küche sind Kartoffeln. Diese kommen nicht nur als Sieglinde oder Annabelle daher, sondern in allen möglichen Farben, Formen und Größen, schließlich haben die Kartoffeln in den Anden ihren Ursprung. Trotz Mais und Kartoffeln ist das Konzept von vegetarischem Essen in Ecuador nicht verbreitet. Eines der wenigen vegetarischen Gerichte ist Cholco con Queso, ein Maiskolben und dazu etwas milder Käse, ganz einfach aber lecker.

![Choclo con Queso - Mais mit Käse](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1475-1024x768.jpg)

Immer wenn es geht, wird Fleisch serviert. Ein ecuadorianischer Klassiker ist zum Beispiel Seco de Chivo, ein Ziegengeschnetzeltes mit einer herzhaften Soße. Dazu werden Reis und andere Beilagen wie Salat oder Kartoffeln serviert. Auch auf der Straße sehr beliebt ist [Fritada](https://en.wikipedia.org/wiki/Fritada). Vereinfacht ausgedrückt handelt es sich um große Stücke gebratenen Schweinefleischs mit Beilagen, z.B. Mais oder Kartoffeln. Der Deutsche könnte eventuell die Soße vermissen ;)

![Fritada: Gebratenes Schweinefleisch mit diversen Mais- und Kartoffelsorten](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1474-1024x768.jpg)

## Dessert

Nachtisch scheint keine ur-ecuadorianische Disziplin zu sein. Natürlich gab es einige Leckereien aus der phantastischen ecuadorianischen Schokolade, Karamell-Flan oder Früchte. Ein Baumtomatenkompott hat uns einmal gut geschmeckt. So richtig typisch für Ecuador hingegen sind Feigen mit Käse (higos con queso). Die Feigen waren zuckersüß und der Käse auf der milden Seite. Irgendwie wurde es nicht unser Favorit - Schokolade ist doch besser ;). Auf Fälle fanden wir Feigen mit Käse bemerkenswert.

![Figos con Queso - Feigen und Käse](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1455-1024x768.jpg)

## Meerschweinchen als Festessen

Eine Spezialität löst unter Touristen Kontroversen aus: das Meerschweinchen. In den Anden wird es als Festessen angesehen und zum Beispiel zu Weihnachten serviert. Nicht umsonst werden die possierlichen Tiere auch auf dem Markt von [Otavalo](http://wittmann-tours.de/otavalo-eine-typisch-ecudorianische-stadt) angeboten. Wir lernten auch, dass die Nager in früheren Zeiten in der Küche gehalten worden waren. Der Vorteil war, dass sie alles fraßen, was an pflanzlichen Stücken auf den Boden fiel, der historische Biomüll sozusagen. Sehr praktisches Konzept, fanden wir. Das Meerschweinchen ist übrigens eines der wenigen Haustiere, das in den Anden heimisch ist und dort domestiziert wurde. Rinder, Schafe, Ziegen, Schweine wurde allesamt von den Europäern mitgebracht.

![Ein knuspriges Meerschweinchen](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1483-1024x768.jpg)

Was den Verzehr von Meerschweinchen angeht, scheiden sich die Geister der Touristen. Die einen lehnen ihn kategorisch ab ("Aber es ist doch so süüüß!"), die anderen probieren gerne. Da wir eher experimentierfreudig sind, bestellten wir an einem Abend in Quito eines für uns beide und haben es sehr genossen. Zusammen mit ein paar Beilagen war das eine vollwertige Mahlzeit, obwohl an einem Meerschweinchen nicht viel dran ist. Es gab vergleichsweise wenig des saftigen, dunkeln Fleisches, dafür viel Haut und diese war extrem knusprig. Der Geschmack erinnerte entfernt an eine Mischung aus Hasenbraten und krossem Miniatur-Spanferkel. Messer und Gabel legten wir nach kurzer Zeit als nutzlos beiseite. Am besten funktionierte der Verzehr wie bei einem echten Rittermahl mit den Händen, um die vielen kleinen Knöchelchen abnagen zu können. Und, würdet Ihr es probieren?
