---
title: 'Der Untergang der Maya'
description: ""
published: 2018-06-21
redirect_from: 
            - https://wittmann-tours.de/der-untergang-der-maya/
categories: "Ausbeutung, Klimawandel, Maya, Mexiko, Mexiko, Politik, Umweltverschmutzung, Untergang"
hero: ../../../defaultHero.jpg
---
# Der Untergang der Maya

Wir besuchten einige Stätten verschiedener präkolumbianischer Kulturen in Mexiko. Einzig der Grund für den Untergang der Azteken ist sehr genau bekannt. In diesem Fall war es die Ankunft und die militärische Überlegenheit der Spanier. Bei den anderen Völkern, und das der Maya ist das präsenteste, ist der Niedergang weiterhin ein gewisses Rätsel, das auch in den zahlreichen Museen, die wir besuchten, nur wenig thematisiert wurde. Stattdessen ging es mehr darum, die damaligen Kulturen zu beschreiben, wie die Menschen gelebt haben, wie ihre spirituelle Welt aussah und was sie uns in Form von Artefakten hinterließen.

![Der Herr des Lebenden Berges, die fleischlosen Lippen symbolosieren den Eingang ins Yibalbá, der Unterwelt der Maya](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180320-153057-7908-1024x683.jpg)

<!--more-->

## Der Untergang der Maya durch Klimawandel?

Auch wenn es vielleicht etwas wissenschaftliches Glatteis ist, wollen wir trotzdem versuchen, einige, auch multifaktorielle, Theorien über mögliche Gründe der Aufgabe vieler prächtiger Maya-Städte zu skizzieren. Hierbei stützen wir uns auf das, was wir bei unseren Besuchen aufgeschnappt haben, auf das sehr interessante Buch ["Kollaps" von Jared Diamond](https://www.amazon.de/dp/3596192587), das unter anderem auch den Untergang der Maya (allerdings speziell in Tikal, Guatemala) untersucht, und unsere eigenen Interpretationen.

![Trotz Ausgrabung, der Dschungel ist immer in Calakmul sichtbar](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180319-112127-7829-HDR-1024x683.jpg)

Eine gängige These lautet, dass ein Klimawandel für den Niedergang der Maya verantwortlich war. Der Klimawandel der Maya ist jedoch ein anderer als der, mit dem wir uns heute konfrontiert sehen. Um ihre herrlichen Städte zu bauen, brauchten sie zunächst einmal Platz. Also rodeten sie großflächig den Wald, um Baugrund zu schaffen und um Ackerbau betreiben zu können, der die Einwohner ernährte. Auch wurde eine bestimmte Baumart zur Herstellung von Mörtel verwendet. Die Abholzung des Dschungels führte zu Bodenerosion, die Ernteerträge gingen zurück, also musste noch mehr Urwald weichen. Dies jedoch führte zu Trockenheit, da der Wald die Feuchtigkeit nicht mehr speicherte, was wiederum die Landwirtschaft erschwerte.

![Der Ballspielplatz in Palenque](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180317-114333-7723-1024x683.jpg)

## Von den Göttern verlassen

Um diesen Effekten entgegenzusteuern, nutzen die Maya die Strategien, die sie kannten. Sie taten ihr Bestes, die Felder zu bewässern und zu düngen. Außerdem opferten sie ihren Göttern, die für elementare Themen zuständig waren: Der Sonne, dem Regen, der Fruchtbarkeit. Die herrschende Klasse nahm für sich in Anspruch, mit den Überirdischen kommunizieren zu können, um das Wohlergehen der Bevölkerung sicherzustellen. Als dies offenbar nicht mehr funktionierte, wurden immer drastischere Opfer eingefordert. Es ist denkbar, daß die Menschen beim Ausbleiben von Erfolgen den Glauben an und die Loyalität gegenüber der Obrigkeit verloren haben.

![Mehr Baum aus Ruine, der Dschungel erobert sein Gebiet zurück](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180318-145725-7793-HDR-1024x683.jpg)

Zusätzlich wird auch ein globaler Faktor diskutiert, der zeitlich in die Phase des Untergangs der Maya fällt, die [mittelalterliche Warmzeit](https://de.m.wikipedia.org/wiki/Mittelalterliche_Warmzeit). Dies würde dahingehend passen, dass diese um ca. 900 n. Chr. anfing und dass die Aufgabe der Maya-Städte grob in diesem Zeitrahmen begann. Vielleicht hat diese Warmzeit die Folgen des Raubbaus an der Natur zusätzlich verschärft. Wenn man diese möglichen Effekte zusammen betrachtet, war das Klima (und dadurch bedingte Dürren) wahrscheinlich ein Faktor für den Niedergang, aber bestimmt nicht der einzige, denn die verschiedenen Maya-Städte sind nicht alle zur gleichen Zeit untergegangen, sondern es war ein Prozess, der sich über gut 150 Jahre hinzog.

## Weitere Faktoren für den Untergang

Kriege zwischen den Maya-Stadtstaaten waren wohl ein weiterer Faktor. Bei knapper werdenden Ressourcen kam es vermutlich zu Verteilungskämpfen, im Kleinen zwischen einzelnen Menschen und im Großen zwischen den Städten. Eventuell wurde dadurch weniger Energie auf die Landwirtschaft verwendet, was wieder zu geringeren Erträgen führte, ein Teufelskreis.

![Der Ballspielplatz von Calakmul, die Gewinner wurden den Göttern geopfert](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180319-131452-7856-1024x683.jpg)

Zuweilen werden alte Kulturen stark idealisiert. In diesem Fall scheint es aber offensichtlich zu sein, dass auch die Maya kein universelles Verständnis der Natur hatten, wie es manchen Völkern oft zugesprochen wird. Sicher hatten sie ein umfassendes Wissen über Tiere, Pflanzen und Ökologie des Dschungels und konnten dieses geschickt nutzen. Trotzdem ist es wahrscheinlich, dass die Maya u.a. durch zu extensive Ausbeutung der Natur den Niedergang der eigenen Kultur verursacht haben. Auch die blutigsten Opferrituale konnten den Prozess nicht zum Stillstand bringen.

![Kunstvolle Maya-Glyphen](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180317-140611-7783-1024x683.jpg)

Die Antwort der herrschenden Schicht war anscheinend nicht die richtige. Statt immer drastischere Opfer zu fordern, hätten andere Lösungsansätze vielleicht den Untergang der Gesellschaft verhindern und ihre eigene Stellung erhalten können. Zu dieser Einsicht ist es anscheinend jedoch nicht gekommen. Die Reaktion auf die offensichtlichen Probleme schienen überlieferte Glaubensrituale zu sein, nach den wirklichen Ursachen wurde wohl nicht adäquat gesucht. Diese mangelnde intellektuelle Anpassungsfähigkeit könnte ein weiterer aggravierender Faktor gewesen sein.

## Der Untergang der Maya - eine Lehre für die Gegenwart?

Damals hätten es sich die Herrscher eines Millionenvolks wohl nicht träumen lassen, dass nach vergleichsweise kurzer Zeit nur noch wenige Menschen übrig sein würden. Alle waren abgewandert, gestorben und es gab zu wenige Geburten. Nur noch wenige Prozent der damaligen Bevölkerung lebten nach dem Niedergang in der Region. Die Pracht der mächtigen Maya-Stadtstaaten war vergangen.

![Die ganze Pracht der Maya, die Grab-Pyramide von Pakal I.](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180317-095935-7704-1024x683.jpg)

Auch wir wähnen uns heute unverwundbar und tun unser Bestes, die Welt nach allen Regeln kurzfristiger Profitmaximierung auszubeuten. Ignorante Herrschern leugnen den Klimawandel. Luft- und Wasserverschmutzung, Überfischung der Meere, Plastikmüll überall und vieles mehr sind bereits kaum mehr rückgängig zu machende Schäden, spielen aber in der Gegenwartspolitik eine viel zu geringe Rolle. In der täglichen Debatte sind es meistens andere Themen, die Schlagzeilen machen. Weiter so wie bisher, wir werden schon eine Lösung finden, Hauptsache, wir schlagen erstmal maximalen Gewinn für uns selbst aus der Sache. Kritische Stimmen nennen den Klimawandel unumkehrbar und das willkürliche Ziel einer Begrenzung der Erderwärmung auf 2 Grad [unerreichbar](https://www.wired.com/story/the-dirty-secret-of-the-worlds-plan-to-avert-climate-disaster/).

![Die ganze Pracht der Maya, die Grab-Pyramide von Pakal I.](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180320-151314-7894-1024x683.jpg)

Wir wollen kein Weltuntergangsszenario zeichnen, aber etwas Demut würde der gesamten Weltbevölkerung vermutlich gut tun. Wir haben mittlerweile über 10 Länder bereist und überall stoßen wir auf ähnliche Probleme: Ausbeutung der natürlichen Ressourcen zu Lasten folgender Generationen und Umweltverschmutzung. Es ist Aufgabe jedes Einzelnen, seinen Teil dazu zu tun, bewusster zu leben, seine wirklichen Bedürfnisse zu reflektieren und sein Verhalten zu überdenken. Noch mehr aber sollten die Politiker, als die (demokratische) Machthaber, überall auf der Welt die Pflicht haben, vor allem die großen Konzerne in die Verantwortung zu nehmen, sich nicht von ihnen kaufen oder unter Druck setzen zu lassen und sie zu fairem, umweltbewussten und zukunftsweisenden Verhalten zu zwingen.

## Die Maya sind noch da

Trotz des Unterganges ihrer glanzvollen Vergangenheit leben heute noch viele Maya. Sie sprechen diverse [Maya-Sprachen](https://de.wikipedia.org/wiki/Maya-Sprachen) und verfolgen alte Bräuche und Traditionen, die sich teilweise mit christlichen und modernen Einflüssen vermischt haben. Die Maya zählen wieder mehrere Millionen Menschen in den Ländern Mexiko, Belize, Guatemala und Honduras. Der alte Glanz jedoch ist vergangen. Die heutigen Maya sind nicht selten die Ärmsten in den genannten Ländern. Die auch heute noch sehr beeindruckenden Ruinenstädte sind Zeugen der historischen Pracht und sollten uns in der Gegenwart eine Mahnung sein.

![Nach dem Untergang: Ruinen und Urwald sind untrennbar ineinander verschlungen, eines der weniger besuchten Gebiete in Palenque](http://wittmann-tours.de/wp-content/uploads/2018/05/CW-20180318-124804-7747-HDR-1024x683.jpg)
