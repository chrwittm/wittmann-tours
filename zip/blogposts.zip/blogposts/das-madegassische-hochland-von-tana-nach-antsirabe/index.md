---
title: 'Das madegassische Hochland - von Tana nach Antsirabe'
description: ""
published: 2019-04-21
redirect_from: 
            - https://wittmann-tours.de/das-madegassische-hochland-von-tana-nach-antsirabe/
categories: "Aluminium, Ambatolampy, Fady, Famadihana, Hochland, Kapoka, Madagaskar, Madagaskar, Malagasy, Merina, Taxi Brousse, Totenumwendung, Tradition"
hero: ../../../defaultHero.jpg
---
# Das madegassische Hochland - von Tana nach Antsirabe

Wir verließen Antananarivo schon am Tag nach unserer Ankunft, würden aber später dorthin zurückkehren. Wir folgten der Nationalstraße Nummer 7, einem schmalen Asphaltband, bis nach Antsirabe, 170 Kilometer von Tana entfernt. Der Zustand der Straße verschlechterte sich mehr und mehr, je weiter wir nach Süden gelangten. Und genau dieser Weg war für heute das Ziel. Unterwegs lernten wir das Madegassische Hochland und seine Bewohner kennen.

![Ein kleines Hochland-Dörfchen entlang der Nationalstraße 7, südlich von Antananarivo.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180811-150236-9191-1024x683.jpg)

<!--more-->

## Die Merina - Bewohner des Hochlandes

Auf Madagaskar gibt es [viele Völker](https://de.wikipedia.org/wiki/Foko). 18 Foko, offiziell anerkannte Volkstämme, haben in mehreren Wellen die Insel besiedelt. Im Hochland rund um Antananarivo leben die [Merina](https://de.wikipedia.org/wiki/Merina), die erstaunlich asiatisch aussehen. Obwohl Madagaskar nur 450 Kilometer vom afrikanischen Kontinent entfernt ist, sind sich diverse wissenschaftliche Disziplinen, wie die Genetik, Linguistik und Archäologie, mittlerweile einig: Die ersten Einwanderer Madagaskars kamen aus dem heutigen Indonesien. Auch heute noch ist [Malagasy](<https://de.wikipedia.org/wiki/Malagasy_(Sprache)>), neben Französisch die offizielle Landessprache Madagaskars, eng mit Dialekten von Borneo verwandt. Das wohl bekannteste madegassische Musikinstrument, die [Valiha](https://de.wikipedia.org/wiki/Valiha), eine Bamubszither, ist malaiischen Ursprungs. Afrikanische und arabische Einflüsse kamen erst viel später hinzu. Ein Beispiel dafür ist vermutlich die Begrüßungsformel: "Salama".

![Die Gesichtszüge vieler Madegassen sind eher asiatisch als afrikanisch.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-155156-6950-683x1024.jpg)

An der Straße herrschte überall ein geschäftiges Treiben. Der Verkehr bewegte sich auf dem Weg nach Süden eher langsam voran und wir lernten eine weitere Vokabel: "Mura, mura", "Langsam, langsam". Die Uhren gehen nicht so schnell auf Madagaskar. Im Vorbeifahren fielen uns vor allem zwei Berufsgruppen auf: die Reisbauern und die Lehmziegelhersteller. Beide Tätigkeiten sind traditionell sehr wichtig, da Reis das Hauptnahrungsmittel auf der Insel ist und die Menschen ihre Häuser aus diesen Backsteinen bauen. Ein Ziegel kostet 100 Ariary pro Stück. Für ein Haus braucht man ca. 25000 Steine, macht 2.5 Mio Ariary pro Haus, klingt viel, sind aber nur 625 Euro.

![Lehmziegelherstellung](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180803-082133-7131-1024x683.jpg)

## Traditionen des Hochlandes

Unterwegs erzählte uns Tahina viel über die faszinierenden Traditionen der verschiedenen Volksgruppen, hier natürlich der Merina. Ein wichtiges Thema sind Tabus (Fady), die sich auf ein bestimmtes Verhalten, gewisse Orte etc. beziehen können. Was [Fady](https://de.wikipedia.org/wiki/Fady) ist, kann regional und bei verschiedenen Volksgruppen sehr unterschiedlich sein. So ist in einigen Gegenden das Essen von Gänsen verboten, woanders das Tragen von roter Kleidung auf einer Beerdigung. Manche Tabus gelten nur für Frauen oder Männer oder beziehen sich auf einen bestimmten Wochentag. Was sich manchmal kurios anhört, hat in der Regel durchaus einen tieferen Sinn, der nicht immer sofort erkennbar ist, manchmal auf überlieferten Legenden beruht oder für unser Verständnis im Bereich des Aberglaubens anzusiedeln wäre.

![Die Völker Madagaskars: Eine Stehle in Antsirabe](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180802-083449-6992-683x1024.jpg)

Ein universelles Fady ist, dass man nicht mit dem Zeigefinger auf etwas weisen darf (stattdessen nur mit der geöffneten Hand oder dem abgewinkelten Zeigefinger). Eigentlich ist es tabu, auf Gräber zu zeigen, aber um nicht in einer gedachten unendlichen Verlängerung versehentlich den Finger auf ein Grab zu richten, geht der Madegasse lieber auf Nummer sicher und nutzt den ausgestreckten Zeigefinger generell nicht.

## Die Totenumwendung

Auf Madagaskar nimmt der Ahnenkult einen zentralen Stellenwert in der Glaubenswelt der Bevölkerung ein. Anders als in unserer westlichen Vorstellung bleiben die Ahnen (Razana) nach ihrem Tod ein fester Bestandteil der Familie, mehr noch, sie werden verehrt, müssen gnädig gestimmt werden, können Ratschläge erteilen und zwischen der spirituellen Ebene und der Welt der Menschen vermitteln. Eine wesentliche Feierlichkeit der Ahnenverehrung ist die [Famadihana](https://de.wikipedia.org/wiki/Famadihana), die sogenannte Totenumwendung, die alle 7 oder 10 Jahre gefeiert wird.

![Ein typisches Familiengrab im Hochland](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180802-165307-7096-1024x683.jpg)

Die Famadihana ist ein großes Fest für die ganze Familie und die Ahnen sind auch dabei, nicht nur im Gedenken der Menschen, sondern physisch. Ihre Leichname werden aus dem Familiengrab geholt und herumgetragen. Dann erzählen die Angehörigen ihnen die neusten Neuigkeiten, Klatsch und Tratsch und junge Familienmitglieder werden ihnen vorgestellt. Außerdem umwindet man sie mit einem neuen, zusätzlichen, oft aufwändig bestickten Leichentuch. Am Ende der Feierlichkeiten werden die Ahnen wieder im Familiengrab zur Ruhe gebettet, oft jedoch auf einer höheren Ebene.

## Gegenseitiger Respekt

Tahina erläuterte diesen Brauch nicht nur, sondern wir hielten auch an einigen Gräbern an, um uns diese (natürlich nur von außen) anzuschauen. Wir standen also am Rande der Straße in der Nähe der Grabhäuser und waren kurze Zeit später von einer Gruppe Kinder umringt, die uns beguckten und um Süßigkeiten baten. Wer viel gereist ist, könnte sich jetzt ausmalen, wie es weitergeht: Die Kinder fragen und fragen, es wird immer lästiger und lästiger, am Ende fahren wir weiter und alle haben ein ungutes Gefühl. Hier verlief die Geschichte aber erstaunlicherweise etwas anders.

![Neugier und Respekt: Die Kinder sangen die madegassische Nationalhymne](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-154720-8207-HDR-1024x683.jpg)

Tahina traf mit den Kindern eine Vereinbarung mit folgendem Ergebnis: Zuerst gaben sie ihm die Zeit, uns die Gräber zu zeigen und seine Erklärungen über die Totenumwendung zu beenden. Anschließend sangen die Kinder für uns die madegassische Nationalhymne und dann bekamen sie alle eine kleine Belohnung in Form von einigen Crackern. Schließlich waren alle glücklich und die Kinder winkten uns hinterher, als wir abfuhren.

![Am Ende gab es eine kleine Belohnung](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-154901-8215-1024x683.jpg)

Interessant an dieser Begegnung sind unserer Meinung nach zwei Sachverhalte: Zum einen fand sie in gegenseitiger Achtung statt. Wir behandelten die Kinder freundlich und sie lernten, uns als Besucher zu respektieren. Natürlich haben wir uns die positive Begegnung durch ein bisschen Bestechung erkauft, aber die Kinder erbrachten durch ihren Gesang auch eine Gegenleistung. Häufig sehen die Madegassen sonst in den Touristen die unerschöpflich reichen Vazahas, die wahllos Geschenke verteilen und das fördert naturgemäß die Bettelei. In solchen Situationen kann ein guter Reiseleiter Brücken bauen.

## Der Markt von Ambatolampy

Unterwegs fuhren wir an vielen Ständen vorbei, an denen die Produkte des Hochlandes, Obst, Früchte oder Gemüse, verkauft wurden. Mehr Zeit hatten wir hingegen in Ambatolampy, Tahinas Heimatstadt, um uns das Warenangebot auf dem Markt anzuschauen. Dabei fiel uns auf, dass die meisten Lebensmittel lose veräußert wurden: Reis, Bohnen, Mais etc. Zum Abmessen der Menge benutzten die Verkäufer eine leere Konservendose (meist Kondensmilch), die in Madagaskar ein Standardmaß ist, die sogenannte Kapoka.

![Kapoka - Die Füllung einer Dose Kondensmild ist ein Standardmaß für den Verkauf von Reis, Bohnen, Erbsen etc.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-132002-8161-1024x683.jpg)

Am Rande des Marktes hätten wir eine kleine Holzhütte bestimmt übersehen, wenn Tahina uns nicht darauf hingewiesen hätte. In dem Hüttchen befand sich das örtliche Kino. Darin gab es keine Leinwand, sondern einen kleinen Röhren-Fernseher und viele Kinder, die wie gebannt in die Glotze starrten. Der Eintritt kostete 50 bis 100 Ariary und Tahina hatte als Kind auch schon auf den gleichen Holzbänken gesessen.

![Auf dem Markt von Ambatolampy](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-135656-6943-1024x683.jpg)

## Bei den Aluminium-Gießern

Nachdem wir den Markt hinter uns gelassen hatten, besuchten wir eine Aluminium-Gießerei. Dort werden typisch madegassische Töpfe, Eimer, Schlüsselanhänger etc. gefertigt und anschließend überall auf der Insel verkauft. Und in der Tat, diese Art von Kochgeschirr sahen wir wirklich überall auf Madagaskar, meistens in groß oder noch größer. Das Aluminiumhandwerk blüht in Ambatolampy, da man nur dort den speziellen Sand findet, den man für dieses Gewerbe benötigt. Die Arbeiter erstellen aus diesem Sand ein Negativ des zu gießenden Gegenstands, um anschließend die Form aufzufüllen. Klingt unmöglich, aber es funktioniert!

![Der Eimer im Vordergrund ist das Original für die Herstellung vieler weiterer.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-133536-6938-1024x683.jpg)

## Ein Eimer entsteht

Wir durften bei der Herstellung eines Eimers zusehen. Im ersten Schritt wird ein gut gelungener Muster-Eimer mit Sand gefüllt und dieser wird festgestampft, so dass es keine Zwischenräume gibt. Die Topfgießer säubern eine Bodenplatte und stellen den gefüllten Eimer kopfüber (also inkl. seiner Füllung) darauf. An dieser Platte sind Metallstäbe befestigt, die dazu dienen, quadratische Holzformen (sie sehen wie Schubladen ohne Böden aus) exakt aufstapeln zu können. Diese Kästen werden nun, Ebene für Ebene, mit Sand aufgefüllt und der Inhalt wird jedes Mal neu komprimiert. Dies wiederholen die Handwerker Schicht für Schicht, bis der zu gießende Gegenstand komplett in einer so entstandenen offenen Holzkiste unter festgestampftem Sand begraben ist.

![Die Sandform ist fertig. Die Schubladen mit dem festen Sand werden entfernt und das Original entnommen.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-133954-8187-1024x683.jpg)

Anschließend heben die Männer die Holzkästen einen nach dem anderen vorsichtig wieder ab. Erstaunlicherweise klebt der Sand in den Formen, so dass sie das Negativ zur Außenwand des Eimers darstellen. Sind alle Kästen entfernt, wird der Original-Eimer entnommen - die Sandfüllung bleibt stehen - und die Kisten werden wieder aufgesetzt. Der so entstandene Zwischenraum wird nun mit flüssigem heißen Aluminium ausgegossen. Einem Arbeitsschutzbeauftragten stünden die Haare zu Berge, von Schutzkleidung oder -brille ist weit und breit keine Spur zu sehen. Die Topfgießer üben ihre Tätigkeit lässig in kurzen Hosen und barfuß aus, während sie mit dem rotglühenden Aluminium hantieren…

![Glühendes Aluminium strömt in die Form. Der neue Eimer wird gegossen.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180801-134400-8194-683x1024.jpg)

Nun dauert es nicht lange, bis das Aluminium fest wird. Nach Entfernen des Sandes kommt der dampfende neue Eimer zum Vorschein.

## 170 Kilometer an einem Tag

Wir (Mona und Christian) waren auf der Nationalstraße Nummer 7 schon im Jahre 2011 unterwegs gewesen. Auch wenn wir uns an Vieles noch erinnern konnten, genossen wir dennoch die Fahrt und die vielen Eindrücke. Erneut stellten wir fest, dass sich relativ wenig verändert hatte, auf dem Land noch weniger als in der Stadt. Ein Zeichen des Fortschritts fuhr auf den Straßen: Als Taxi Brousse (Minibusse, die als öffentlicher Nah- oder Fernverkehr operieren) hatten früher mehr oder weniger klapprige Mini-Vans japanischer Hersteller verkehrt. Nun sahen wir hauptsächlich recht solide wirkende Mercedes Sprinter, die als Busch-Taxi fungierten.

![Ein typisches Taxi-Brousse. Aufgrund der Ladung kann man nur erahnen, wie eng es drinnen zugehen muss.](http://wittmann-tours.de/wp-content/uploads/2019/03/CW-20180805-093628-7290-1024x683.jpg)

Der Betriebsmodus der Taxi Brousse war jedoch anscheinend immer noch der gleiche. Sie fahren los, wenn sie voll sind. Voll bedeutet dabei, dass pro Sitzreihe mindestens 2 Personen mehr mitfahren, als es Plätze gibt. Das Gepäck ist kreativ im ganzen Fahrzeug gestapelt, auf dem Fußboden, auf dem Schoß der Passagiere und auf dem Dach. Eine Fahrt mit dem Taxi Brousse wäre sicher ein sehr authentisches Erlebnis gewesen, allerdings auch abenteuerlich im Sinne von unbequem, unsicher und unzuverlässig. Außerdem hätten wir die ganzen Stopps verpasst, die diesen Tag unvergesslich machten.
