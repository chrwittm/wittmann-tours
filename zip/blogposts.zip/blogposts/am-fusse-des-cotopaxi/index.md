---
title: 'Am Fuße des Cotopaxi'
description: ""
published: 2018-09-19
redirect_from: 
            - https://wittmann-tours.de/am-fusse-des-cotopaxi/
categories: "Ausritt, Cotopaxi, Ecuador, Ecuador, Laguna Limpiopungo, Nationalpark, Pferde, Pucará, Reiten, Wasserfall"
hero: ../../../defaultHero.jpg
---
# Am Fuße des Cotopaxi

Unser letztes Ziel in Ecuador war der Cotopaxi, der mit 5897m [zweithöchste Berg](https://de.wikipedia.org/wiki/Cotopaxi) Ecuadors, ein immer noch aktiver Vulkan. Gipfelambitionen hatten wir keine, dafür war unsere bisherige Höhenanpassung ganz und gar nicht ausreichend. Stattdessen verbrachten wir einige Tage in einer schönen Lodge kurz vor dem Eingang des Nationalparks und unternahmen Wanderungen und Ausritte.

![Der Cotopaxi am frühen Morgen (fast) ohne Wolken, dafür mit Lama](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180429-071207-1612-1024x683.jpg)

<!--more-->

## Der Cotopaxi, ein Verhüllungskünstler

So schön klar und majestätisch wie oben auf dem Bild sahen wir den Cotopaxi allerdings nur selten. Bei unserer Ankunft am späten Vormittag war kein bisschen Berg zu sehen. Es war bewölkt, neblig und am Nachmittag fing es sogar zu regnen an. Erst am nächsten Morgen hatte es aufgeklart (Bellavista und der Pululahua lassen grüßen). Da stand der, der Cotopaxi, scheinbar direkt vor dem Fenster des Frühstücksraums erhob er sich aus der Ebene, fast wie auf einer Foto-Tapete mit seiner dekorativen Eis- und Schneekappe. Der Gipfel überragte uns (die Lodge befand sich auf knapp 3700m) in 15 Kilometern Entfernung immer noch um 2200 Meter. Allein schon bei diesen Zahlen kann einem die Luft wegbleiben.

![Fast am gleichen Standort aufgenommen: Gut Verhüllt: Der Cotopaxi](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1494-1024x683.jpg)

Trotz des eher mäßigen Wetters unternahmen wir am Nachmittag eine kleine Wanderung zu einem nahegelegenen Wasserfall, eine vom Hotelmanager handgemalte Wanderkarte wies uns den Weg. Wir waren kaum 50 Meter unterwegs und schon hatten wir einen Begleiter, Yana-Yuraq (Schwarz-Weiß auf Quechua), den Hund des Hotelbesitzers. Endlich ging mal jemand mit ihm Gassi ;). Und dann sind die Besucher auch noch so wunderbare Spielgefährten, die so viele tolle Stöckchen finden und werfen!

![Yana-Yuraq mit unbändiger Energie beim Stöckchenholen](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180428-135916-1553-1024x683.jpg)

Yana-Yuraq war wirklich kaum zu bremsen und sauste am liebsten in dynamischem Galopp über die Weiden und zwischen den kleinen Büschen hindurch. Das ganze Land um den Cotopaxi herum (auch im [Nationalpark](https://de.wikipedia.org/wiki/Cotopaxi-Nationalpark)) wird für Weidewirtschaft genutzt, meistens für Kühe, aber auch für Lamas. Dabei waren die Lamas eher harmlos, aber vor den Rindern sollten wir uns in acht nehmen. Nach vielleicht 2 oder 3 Kilometern querfeldein erreichten wir den Wasserfall. Yana-Yuraq hatte bestimmt mindestens den doppelten Weg zurückgelegt ;)

![Ein kleiner Wasserfall, das Ziel unserer ersten Wanderung](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180428-143944-9718-1024x683.jpg)

## Ausritt am Fuße des Cotopaxi

Am nächsten Morgen wurden wir von der Sonne geweckt und der Cotopaxi begrüßte uns in all seiner Pracht. Auch die anderen Berge in unserer Umgebung waren zu sehen, der [Rumiñahui](<https://de.wikipedia.org/wiki/Rumi%C3%B1ahui_(Vulkan)>) (4721m), der [Pasochoa](https://en.wikipedia.org/wiki/Pasochoa) (4199m) und der [Sincholagua](https://en.wikipedia.org/wiki/Sincholagua_Volcano) (4873m).

![Am Morgen auch ohne Wolken, der Rumiñahui (4721m)](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180429-072441-1645-1024x576.jpg)

Für diesen Morgen hatten wir einen Ausritt geplant. Die Panoramakulisse war aber leider nicht von Dauer. Als wir losritten zogen immer mehr Wolken auf und der Cotopaxi verhüllte sich zusehends.

![Ausritt vor Bergpanorama](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180429-082252-9749-1024x683.jpg)

Das Ziel des Ausrittes war Pucará, die Ruine einer alten Inka-Festung auf einem Hügel. Auch wenn der Ausblick von dort sehr schön war, ohne den Cotopaxi, der sich bis dahin vollständig in den Wolken versteckt hatte, fehlte doch der Hauptprotagonist. Damit war eher der Weg das Ziel. Wir ritten durch die hügelige Landschaft, die zuweilen erstaunlich grün war. Große Grasbüschel säumten unseren Weg, der uns auch entlang des Rio Pita führte. Der Fluss hatte sich im Laufe der Zeit einen vielleicht hundert Meter tiefen Canyon gegraben, an dessen oberem Rand wir entlang ritten.

![Saftiges Grün im Cotopaxi Nationalpark](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180429-090700-9770-1024x683.jpg)

## Zu Fuß im Cotopaxi-Nationalpark, wie absurd!

Am Nachmittag unternahmen wir erneut eine Wanderung. Diesmal ging es in den Cotopaxi-Nationalpark und wieder leitete uns eine handgezeichnete Karte. Yana-Yuraq musste zu seiner großen Enttäuschung allerdings zu Hause bleiben. Haustiere sind im Nationalpark nicht erlaubt. Als wir den Parkeingang erreichten, lernten wir allerdings, dass auch Fußgänger im Park verboten sind. Offiziell darf man sich nur im Auto oder zu Pferd auf dem Gelände bewegen. Der Grund hierfür sind die freilaufenden wilden Rinder.

![Vorsicht vor den Kühen!](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180429-145146-9792-Edit-1024x683.jpg)

Unsere Verwunderung könnt ihr Euch denken: Ein Nationalpark, in dem man nicht wandern darf? Ehrlich? Wir erklärten dem Parkwächter unsere Route (schließlich hatten wir die Karte dabei) und daraufhin ließ er uns doch passieren, aber wir sollten uns vor den Stieren in acht nehmen! Die Kühe (und auch einige Wildpferde) sind anscheinend wirklich herrenlos. Sie blieben zurück, als einige Bauern ihre Farmen aufgaben und vermehrten sich prächtig.

![Die Lamas waren uns wesentlich lieber als die Kühe](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180429-154246-9794-1024x683.jpg)

## Kalt und windig, aber sehr sehenswert

Auch am nächsten Tag unternahmen wir einen Ausritt, was eher eine Notlösung war, da sich unser Wunschprogramm nicht realisieren ließ. Der Tag war ein Feiertag und alle lokalen Guides waren ausgebucht. So ritten wir zur Laguna Limpiopungo, was ein sehr schönes Alternativprogramm war :). Bisher hatten wir den Cotopaxi-Nationalpark als quasi menschenleer erlebt. Der Parkplatz der Lagune hingegen war übervoll mit den Autos vieler Tagesausflügler.

![Graues und kühles Wetter an der Laguna Limpiopungo](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180430-110653-9811-1024x683.jpg)

Wie auch am Tag zuvor hatte sich der schüchterne Cotopaxi schon lange in den Wolken versteckt. Wir ließen die Pferde zurück, um am Rande des Sees entlang zu spazieren. Rund um die Lagune war es auf 3900m erstaunlich grün und einige Vögel hüpften durch die Büsche. Als besonderer Höhepunkt galoppierte eine Herde schwarzer Wildpferde durch die weite Landschaft. Zusätzlich zum kalten Wind fing es schließlich auch zu regnen an. Zurück auf den Pferden gab es glücklicherweise Sitzheizung ;) und auch der Regen ließ nach. Trotzdem waren wir am Ende froh, wieder in unserer Unterkunft angekommen zu sein, um uns aufzuwärmen.

![Endlich mollig warm :)](http://wittmann-tours.de/wp-content/uploads/2018/07/APC_1495-1024x683.jpg)

Super-mollig war es dort allerdings auch nicht, sondern eher landestypisch kühl, obwohl wir einen kleinen (leicht überforderten) Elektroheizkörper im Zimmer hatten. Im riesigen Speisesaal, der auch als Aufenthaltsraum diente, war die einzige Heizung ein kleines Holzöfchen. Also galt es pünktlich zum Abendessen zu erscheinen, um einen Platz nahe des Ofens zu ergattern. Noch besser war es, vorher die Bilder des Tages vor dem Kamin zu sichten oder dort Blog zu schreiben. So konnte selbst der kalte Cotopaxi-Nationalpark seine gemütlichen Seiten haben ;)
