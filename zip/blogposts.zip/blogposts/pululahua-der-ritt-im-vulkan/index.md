---
title: 'Pululahua: Der Ritt im Vulkan'
description: ""
published: 2018-09-04
redirect_from: 
            - https://wittmann-tours.de/pululahua-der-ritt-im-vulkan/
categories: "Ausritt, Ecuador, Ecuador, Nebel, Pferde, Pululahua, Reiten"
hero: ./img/wp-content-uploads-2018-07-CW-20180425-085904-1467-1024x683.jpg
---
# Pululahua: Der Ritt im Vulkan

Da waren wir schon über ein halbes Jahr unterwegs und es hatte sich noch keine echte Gelegenheit zum Reiten ergeben. Das sollte sich nun in Südamerika ändern. Nachdem ich schon vor 13 Jahren einen Tagesritt im Pululahua-Krater gemacht hatte, war es höchste Zeit für eine Wiederholung.

![Blick in den Pululahua Krater von "El Mirador". Der Berg links im Hintergrund gehört nicht zum Kraterrand. Er ist ein ein Hügel im Krater.](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180425-083627-1465-1024x683.jpg)

<!--more-->

## Fahrt in den Vulkan

Praktischerweise hatte der Reiterhof uns einen direkten Transport in den Krater organisiert. Gut 5 Kilometer nördlich von Mitad del Mundo schlängelte sich eine gute Schotterpiste die Innenwand des Vulkans herunter. Vorher hielten wir kurz beim Aussichtspunkt "El Mirador" an, um von oben in den Krater zu schauen.

![Auf der Fahrt in den Krater zogen schon die ersten Wolken auf.](./img/wp-content-uploads-2018-07-CW-20180425-085904-1467-1024x683.jpg)

Der [erloschene Vulkan](https://de.wikipedia.org/wiki/Pululahua) ist als solcher nicht auf Anhieb zu erkennen, da die Caldera einen Durchmesser von 12 Kilometern aufweist und auf der Ostseite eine Öffnung hat. Daher herrscht im Krater ein ganz besonderes Klima. Im Gegensatz zur trockenen Luft im Hochland ist es dort feucht wie im Nebelwald. Pululahua ist Quechua und bedeutet "Wolke aus Wasser", wie treffend! Morgens ist der Himmel meistens klar, aber je später der Vormittag, desto mehr Feuchtigkeit zieht aus der Richtung des Amazonasgebietes in den Krater und kondensiert dort zu Nebel und Wolken.

![Nebelwaldfeeling im Pululahua](./img/wp-content-uploads-2018-07-CW-20180425-102740-9499-1024x683.jpg)

Daher eignet sich der Kraterboden des inaktiven Vulkans bestens für die Landwirtschaft. Mehrere Familien siedelten sich hier an, um das Gebiet zu bewirtschaften. Die guten Bedingungen für den Ackerbau bestehen auch heute noch, aber immer mehr Bauern verlassen den Vulkan oder satteln auf andere Erwerbszweige um, zum Beispiel bieten sie Übernachtungen und Reittouren an. Es wirkte für uns sehr nostalgisch, dass die Arbeit auf den Feldern noch in reiner Handarbeit ohne Maschinen durchgeführt wurde.

## Die Pferdchen warten schon

Bevor es losging durften wir eine amüsante Videoeinweisung anschauen, die erklärte, wie man ein Pferd reitet. Nach 10 Minuten waren wir also bestens im Bilde und gingen zu unseren Reittieren, die schon auf uns warteten. Mona freundete sich mit Faraon an und ich mit Cozumbo. Unser Gastgeber Gabriel ritt Lucero. Als weitere Begleiter hatten wir seine vier Hunde dabei, darunter Mistica, Bobby und Rocky.

![Christian auf Cuzumbo, Mona auf Noel](./img/wp-content-uploads-2018-07-CW-20180425-102009-9493-1024x683.jpg)

Das Rennen gegen die Wolken hatten wir schon verloren, als wir losritten. An diesem Tag schloss sich die Wolkendecke etwas früher als üblich, was die Reiterfreude aber nicht minderte. Dadurch wirkte die Vegetation im Pululahua-Krater noch authentischer und saftig grün. Auch hier waren abseits der landwirtschaftlichen Nutzflächen viele Bäume mit Flechten und Bromelien verziert. Unser Ziel waren die heißen Quellen etwas tiefer unten im Vulkan, die wir nach gut anderthalb Stunden erreichten.

![Die heißen Quellen im Pululahua Krater. Der Weg war beeindruckender als das Ziel.](./img/wp-content-uploads-2018-07-CW-20180425-113345-9530-1024x683.jpg)

Die heißen Quellen erschienen uns aufgrund des schlammigen Wassers nicht sehr einladend, die Temperatur war allenfalls lauwarm. So vergnügten wir uns damit, Stöcke für Rocky in den Tümpel zu werfen. Der Hund sprang mit lautem Platschen voller Begeisterung ins Wasser auf der Jagd nach den Hölzern. Man musste nur achtgeben, dass er sich danach nicht direkt neben einem schüttelte, sonst war die erfrischende Dusche aus dem Fell des Tieres vorprogrammiert ;).

![Die Pferde erwarteten uns schon für den Ritt zurück nach Hause.](./img/wp-content-uploads-2018-07-CW-20180425-115109-9551-1024x683.jpg)

## Charakteristisches Pululahua-Wetter

Wie nicht anders zu erwarten, fing es wenig später zu regnen an. Zum Glück war es nur ein kurzer Schauer. Auf dem Rückweg ritten wir durch einen tief eingeschnittenen Hohlweg, der schon in präkolonialen Zeiten Teil eines Handelsweges zwischen Amazonasbecken und Hochland gewesen sein soll. Den Hinweg zu den Quellen waren wir eher in beschaulichem Tempo geritten, der Rückweg verlief deutlich spritziger.

![Ein abenteuerlicher Weg, der schon vor hunderten von Jahren benutzt wurde.](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180425-122840-9564-1024x683.jpg)

Zurück auf dem Hof bekamen die Pferde ihr wohlverdientes Futter und auch auf uns wartete ein wunderbares ecuadorianisches spätes Mittagessen. Unser erster Reittag der Weltreise gefiel uns sehr gut und in den kommenden Wochen sollten wir uns noch häufiger in den Sattel schwingen. Nebenbei, kaum hatten wir den Krater auf der Rückfahrt nach Quito verlassen, schien auch schon wieder die Sonne.

![Glückliches Mehlmäulchen](http://wittmann-tours.de/wp-content/uploads/2018/07/CW-20180425-130349-9583-1024x683.jpg)
