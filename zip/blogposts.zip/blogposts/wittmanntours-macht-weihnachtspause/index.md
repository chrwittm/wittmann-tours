---
title: 'Wittmann-Tours macht Weihnachtspause'
description: ""
published: 2019-12-15
redirect_from: 
            - https://wittmann-tours.de/wittmann-tours-macht-weihnachtspause/
categories: "Blog, Weihnachten"
hero: ../../../defaultHero.jpg
---
# Wittmann-Tours macht Weihnachtspause

Vor ziemlich genau einem Jahr sind wir von unserer Reise rund um den Globus [zurückgekommen](http://wittmann-tours.de/zurueck-in-deutschland-home-sweet-home/). Nie hätten wir geglaubt, dass wir 12 Monate später immer noch am Blog schreiben würden. In der Realität zeigt sich, dass die Nachbereitung wohl mindestens nochmal so lange dauern wird wie die Reise selbst ;). Auch wenn das Verfassen der Blogposts durchaus zeitaufwändig ist, liegt uns dieses Projekt doch sehr am Herzen, nicht nur, um Euch zu Hause Gebliebene zumindest in Eurer Phantasie in ferne Länder mitzunehmen, sondern auch, um unsere Erinnerungen lebendig zu halten. Über die Weihnachtstage werden wir uns aber trotzdem eine Blog-Auszeit gönnen, bevor es im Neuen Jahr weitergeht mit Berichten aus Jordanien, Äthiopien und Indien. Euch allen, die Ihr mit Wittmann-Tours virtuell unsere Weltreise begleitet habt, wünschen wir fröhliche und entspannte Weihnachtstage und einen guten Rutsch in ein glückliches Jahr 2020!

![Weihnachtsdeko in Yangon, Myanmar](http://wittmann-tours.de/wp-content/uploads/2017/12/CW-20171127-100909-2870-1-1024x683.jpg)
