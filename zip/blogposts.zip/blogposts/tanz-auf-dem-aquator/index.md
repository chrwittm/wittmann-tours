---
title: 'Tanz auf dem Äquator'
description: ""
published: 2018-08-30
redirect_from: 
            - https://wittmann-tours.de/tanz-auf-dem-aequator/
categories: "Äquator, Calacali, Catequilla, Ecuador, Ecuador, GPS, Intinan, Mitad del Mundo"
hero: ../../../defaultHero.jpg
---
# Tanz auf dem Äquator

Durch Ecuador verläuft der Äquator, das ist ja allgemein bekannt ;). Aber wo genau befindet er sich? Im Zeitalter von Fake News wollten wir den Fakten auf den Grund gehen, unabhängig und unparteiisch, seit Oktober 2017! Dafür besuchten wir die bekannten Denkmäler wie Mitad del Mundo und Intiñán, aber auch die weniger besuchten von Calacalí und Catequilla. Dabei vermaßen wir die Standorte der Monumente mit dem Präzisions-GPS-Gerät Marke Eierkocher Nummer 7 - mit erstaunlichen Ergebnissen!

![Der offiziellste Äquator von Ecuador: Mitad del Mundo](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-100748-9455-1024x1024.jpg)

<!--more-->

## Das erste Äquator-Denkmal

Eines der ersten Äquator-Denkmäler in Ecuador stand am heutigen Mitad del Mundo. Nachdem in den 1970er Jahren die Entscheidung fiel, ein größeres Monument zu bauen, wurde das alte Denkmal nach Calacalí, ein paar Kilometer westlich, verlegt. Auf dem Weg in den [Nebelwald](http://wittmann-tours.de/ecuadors-nebelwald-morgens-auch-mit-bellavista) hielten wir kurz dort an, um das obligatorische Äquator-Foto zu machen, auch wenn es keine aufgemalte Linie am Boden gab, um die Grenze zwischen Nord- und Südhalbkugel zu markieren. So eine Linie wäre sowieso auch nicht richtig gewesen, da das Denkmal 6 Bogensekunden zu weit im Süden liegt ;)

![Das Äquatordenkmal von Calacalí](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180418-063004-8953-Edit-1024x801.jpg)

Was heißt das genau? Eine Bogensekunde nördlicher oder südlicher Breite entspricht am Äquator ungefähr 31 Metern. (Den Rechenweg könnt ihr [hier](http://doc-tcpip.org/Gps/gps_tips.html) nachlesen.) Das Monument steht also gut 180 Meter zu weit im Süden. Für den ersten Besuch bei einem Äquatordenkmal auf dieser Reise schon ganz gut ;)

## Mitad del Mundo

Knapp eine Woche später unternahmen wir einen "Äquatortag", an dem wir weitere Äquatordenkmäler besuchten. Die erste Anlaufstelle hierfür war natürlich [Mitad del Mundo](https://de.wikipedia.org/wiki/Mitad_del_Mundo), die Mitte der Welt, das offizielle Äquatordenkmal. Mit dem Bus dauerte die Fahrt zwei interessante Stunden, einmal quer durch Quito und dann vom Terminal Ofelia weitere 15 Kilometer nach Norden. Im Vergleich zu meinem Besuch vor 13 Jahren hatte sich Mitad del Mundo stark verändert. Dort ist ein Touristendorf gewachsen, das stolz von sich behauptet, die am meisten besuchte Sehenswürdigkeit in Ecuador zu sein. Im Inneren des Monumentes selbst gab es eine Ausstellung, die versuchte, die Physik rund um den Äquator zu erklären und die Vielfalt Ecuadors zu zeigen. Man konnte das Denkmal bis unter den Globus besteigen und heruntersehen.

![Das klassische Bild bei Mitad del Mundo](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-101056-1410-Edit-1024x718.jpg)

Der Ursprung vom Mitad del Mundo liegt mittlerweile mehr als 250 Jahre zurück. Eine französische Expedition hatte den Äquator vermessen und sich dabei ganz gut geschlagen. Die Linie, die auf vielen Bildern von Ecuadorbesuchern zu sehen ist, liegt fast am Äquator, aber trotzdem 8 Bodenminuten (240 Meter) zu weit im Süden.

## Exkurs Schokolade

Im Touristendorf steht nicht nur das Denkmal, sondern einige Pseudomuseen versuchen, mit kleinen Ausstellungen Souvenirverkäufe anzukurbeln. Neben dem Monument besuchten wir nur das Museo de Chocolate. Ecuadors Schokolade gilt als eine der besten der Welt und hier ging es schließlich um wichtige Weiterbildung ;). Die kleine Ausstellung zeigte, wie Schokolade aus Kakaobohnen hergestellt wird. Außerdem propagierte sie Ecuador als das eigentliche Ursprungsland der Schokolade, wer hätte das gedacht ;)

![Eine Weltkarte der Schokolade](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-112349-9471-1024x613.jpg)

Außerdem prieß die Ausstellung die wundersame und auch heilsame Wirkung von Schokolade an, an der wir keinen Moment zweifelten. Schokolade ist natürlich stimmungsaufhellend, gut für den Blutdruck und soll als natürlicher Sonnenschutz wirken. Warum dort nicht stand, das Schokolade auch gegen die Höhenkrankheit hilft war für uns komplett unverständlich, ergänzten es aber gedanklich auf der Liste. Natürlich kauften wir auch 2 Tafeln, des Sonnenschutzes wegen, schließlich ist mit der Sonne direkt am Äquator nicht zu spaßen!

## Intiñán, das alternative Äquator-Museum

Nach einem Mittagessen mit Ausblick am Rande des Pululahua-Kraters (dazu in einem anderen Beitrag mehr) war unser nächster Programmpunkt das [Intiñán-Museum](https://es.wikipedia.org/wiki/Museo_Solar_Inti%C3%B1%C3%A1n). Es ist quasi das alternative Äquatormuseum und wirbt damit, sich wahrhaftig auf dem Äquator zu befinden.

![Ein Lama begrüßte uns im Intiñán-Museum](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-134702-1427-1024x683.jpg)

Der äußerst engagierte Führer bot uns eine sehr praxisnahe und enthusiastische Show. Nach einem kurzen Vorspann über indigene Kultur, Tiere des ecuadorianischen Regenwaldes und Schokolade (es scheint so etwas wie ein Wettrüsten zwischen Intiñán und Mitad del Mundo zu geben) ging es um den Äquator und seine nahezu magischen Eigenschaften, die ihm die [Corioliskraft](https://de.wikipedia.org/wiki/Corioliskraft) verleihen soll. Auf der einen Seite wurden wir darüber unterrichtet, dass Ecuador aufgrund seiner speziellen Lage am Äquator keine Wirbelstürme zu befürchten hat. Auf der anderen Seite demonstrierte uns der Führer sehr eindrücklich, dass aufgrund der Corioliskraft ablaufendes Wasser auf der Nordhalbkugel einen Strudel im Uhrzeigersinn und auf der Südhalbkugel einen gegen den Uhrzeigersinn bildet.

https://www.youtube.com/watch?v=O3sWmGY8n9M

Nun war also eindeutig bewiesen, dass sich sämtliche Kräfte auf dem Äquator aufheben, weshalb auch nur direkt auf der am Boden aufgezeichneten Linie Dinge funktionieren, die sonst nirgendwo auf der Welt möglich wären. Bestes Beispiel: Man kann auf dem Äquator problemlos ein Ei auf einem Nagel balancieren. Persönlich kann ich dies bestätigen: Ich habe zweimal in meinem Leben ein Ei auf einem Nagel balanciert und es war zweimal direkt auf dem Intiñán-Äquator! Eggcellent! ;)

![Eggcellent! Das Ei steht auf dem Intiñán-Äquator](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-144046-9479-1024x683.jpg)

Die Führung war zweifelsohne sehr unterhaltsam! Nun fehlte nur noch unsere unabhängige Messung. Leider mussten wir auch hier feststellen: Knapp daneben! Aber es sind nur 4 Bodensekunden, also knapp 120 Meter. So nah am Äquator war bisher noch kein Denkmal, den Rest könnt Ihr Euch trotzdem selbst denken ;)

![Der Intiñán-Äquator](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-143022-9474-Edit-1024x776.jpg)

## Catequilla, die präkolumbianische Äquatorstätte

Dass das Mitad del Mundo-Monument nicht wirklich 100%-ig auf dem Äquator steht, ist allgemein bekannt, auch wenn man dies vielleicht in Ecuador nicht gerne hört. Intiñán liegt auch etwas daneben, allerdings deutlich näher dran. Es hält sich außerdem hartnäckig das Gerücht, dass es ein antikes Denkmal geben soll, das sich am korrekten Ort befindet. Das wollten wir selbst sehen!

Der Ort heißt [Catequilla](https://en.wikipedia.org/wiki/Catequilla) und wurde von den [Quitu](https://en.wikipedia.org/wiki/Quitu_culture) um das Jahr 800 herum angelegt. Leider scheint der Ort etwas in Vergessenheit geraten zu sein. Durch Bergbauarbeiten ist die Stätte sogar gefährdet und selbst im Lonely Planet wird Catequilla nur in einem Nebensatz erwähnt, ohne Beschreibung, wie man hinkommt. Die Taxifahrer kennen den Ort, allerdings muss man vom Mitad del Mundo aus mit deutlich überhöhten Touristenpreisen rechnen.

Eine Wanderung wäre auch möglich gewesen. Bei 7km pro Weg und 200 Höhenmetern, jedoch sollte man bedenken, dass es durch die Höhe, auf der man sich befindet, anstrengender ist als zu Hause in Deutschland. Da wir erst um 16 Uhr nach Catequilla aufbrachen, kam ein Fußmarsch sowieso nicht mehr infrage, daher wählten wir die bequemere und schnellere Variante mit der Taxifahrt (nach zähen Verhandlungen). Die Piste dorthin ist nicht übermäßig gut und schlängelt sich in Serpentinen einen Berg hinauf, so dass wir für unser Geld wenigstens noch ein bisschen Off-road-Erfahrung erhielten.

Oben angekommen fanden wir nach etwas Suchen die Steinscheibe, auf der eine Diagonale den Äquator anzeigt (nicht gut zu erkennen). Wenn das Wetter besser gewesen wäre, hätten wir einen schönen Blick über einen Teil Quitos gehabt.

![Die Catequilla-Steinscheibe, das Äquatordenkmal der Quitu](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-153726-1436-HDR-Edit-1024x623.jpg)

Ist die Stätte denn genau auf dem Äquator? Nein, auch die Catequilla-Steinscheibe ist nicht ganz darauf, zwei Bogensekunden zu weit im Norden. Aber immerhin ist es wirklich am nächsten dran!

## Gibt es denn überhaupt ein akkurates Denkmal?

Vier Denkmäler, viermal knapp daneben! Wie schwierig kann es denn sein, in Zeiten moderner GPS-Geräte ein akkurates Äquatordenkmal zu bauen? Das müssen sich auch andere gedacht haben. Neben der antiken Catequilla-Steinscheibe befand sich noch ein neueres Denkmal mit einem aus Beton gegossenen runden Sockel und einer in 12 Metallsegmenten in die Höhe ragenden Säule. Kaum zu glauben, es stand wirklich direkt auf dem Äquator, aber leider stand es nicht im Reiseführer!

![Wirklich auf dem Äquator, das "neue" Catequilla-Denkmal](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-154338-1452-Edit-1024x540.jpg)

Was beim neuen Catequilla-Monument allerdings fehlte, war eine dekorativ auf den Boden aufgemalte Äquatorlinie, das gab Abzüge in der B-Note ;). Die einzige echte Äquator-Linie fanden wir, leider stark ausgeblichen, an anderer Stelle. Direkt nördlich vom Intiñán-Museum verläuft eine Straße und siehe da: Südlich der Straße zeigt das GPS 0 Grad 0 Minuten 0 Sekunden südlicher Breite an. Nördlich der Straße zeigt es 0 Grad 0 Minuten 0 Sekunden nördlicher Breite. Auf das klassische Äquatorbild mussten wir wegen des starken Verkehrs allerdings verzichten ;). Am Ende war unsere Suche doch noch von Erfolg gekrönt: Das hier ist der Äquator!

![Wir präsentieren: Der Äquator als Mittelstreifen auf dieser Straße](http://wittmann-tours.de/wp-content/uploads/2018/06/CW-20180424-150034-9482-Edit-1024x444.jpg)

## Epilog

Unsere Messungen spiegeln im Großen und Ganzen das wieder, was man auch auf Wikipedia und aus anderen Quellen nachlesen kann. Trotzdem handelte es sich bei unserer Jagd nach dem Äquator natürlich um eine Pseudojagd, da es DEN Äquator, also eine messerscharfe Linie, gar nicht gibt. Wegen der leichten periodischen Bewegungen der Erdachse kann der momentane Äquator bis zu ca. zehn Metern vom mittleren Äquator entfernt sein. Trotzdem ist der Äquator heutzutage über GPS normiert. Die genauen Hintergründe stehen [hier](https://de.m.wikipedia.org/wiki/Äquator) und [hier](https://de.m.wikipedia.org/wiki/World_Geodetic_System_1984) auf Wikipedia.

Eine weitere Einschränkung ist die Genauigkeit der Messung mit einem Smartphone. Wikipedia gibt eine mögliche Abweichung von bis zu [15 Metern](https://de.m.wikipedia.org/wiki/Global_Positioning_System) an, andere Quellen bescheinigen Smartphones [einen bis drei Meter](https://www.giga.de/extra/gps/tipps/gps-genauigkeit-so-koennt-ihr-sie-erhoehen-android-iphone/) Verlässlichkeit. Wenn man allerdings bedenkt, wie präzise die Orientierung auf Google Maps funktioniert, dann sind es für mich eher nur 1-3 Meter mögliche Abweichung.

Technik hin oder her. Uns hat die Äquator-Jagd auf alle Fälle Spaß gemacht und Euch hoffentlich auch ;)
